package com.example.imdb.config;

public class Config {
}
